create
    definer = root@localhost procedure read_all_available_return_requests()
BEGIN
    SELECT * FROM return_requests WHERE return_mark = false AND repair_cost = 0;
END;

