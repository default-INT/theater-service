create
    definer = root@localhost procedure add_order(IN var_order_date datetime, IN var_rental_period int,
                                                 IN var_client_id int, IN var_car_id int,
                                                 IN var_passport_data varchar(40), IN var_price double)
BEGIN
    IF ((SELECT available FROM cars WHERE id = var_car_id) = true) THEN
        INSERT INTO orders(order_date, rental_period, return_date, client_id, car_id, passport_data, price, closed)
        VALUES (var_order_date, var_rental_period, DATE_ADD(var_order_date, INTERVAL var_rental_period HOUR), var_client_id, var_car_id, var_passport_data, var_price, false);
        UPDATE cars SET available = false WHERE id = var_car_id;
    END IF;
END;

