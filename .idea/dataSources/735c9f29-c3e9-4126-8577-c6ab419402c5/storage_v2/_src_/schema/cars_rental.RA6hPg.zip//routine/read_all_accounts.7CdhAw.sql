create
    definer = root@localhost procedure read_all_accounts()
BEGIN
    SELECT * FROM accounts;
END;

