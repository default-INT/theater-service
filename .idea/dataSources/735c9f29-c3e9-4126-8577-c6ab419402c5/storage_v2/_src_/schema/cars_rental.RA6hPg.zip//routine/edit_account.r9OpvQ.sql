create
    definer = root@localhost procedure edit_account(IN var_id int, IN var_login varchar(16),
                                                    IN var_password varchar(50), IN var_full_name varchar(30))
BEGIN
    UPDATE accounts SET
        login = var_login,
        password = var_password,
        full_name = var_full_name
    WHERE id = var_id;
END;

