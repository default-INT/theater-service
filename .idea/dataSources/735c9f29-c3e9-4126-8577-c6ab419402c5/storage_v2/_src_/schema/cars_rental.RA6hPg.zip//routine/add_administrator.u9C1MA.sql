create
    definer = root@localhost procedure add_administrator(IN var_login varchar(16), IN var_password varchar(50),
                                                         IN var_email varchar(60), IN var_full_name varchar(30))
BEGIN
    INSERT INTO accounts (login, password, email, role, full_name)
    VALUES  (var_login, var_password, var_email, true, var_full_name);
END;

