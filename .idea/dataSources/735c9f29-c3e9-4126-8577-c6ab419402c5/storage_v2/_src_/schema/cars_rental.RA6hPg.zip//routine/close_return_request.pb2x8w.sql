create
    definer = root@localhost procedure close_return_request(IN var_id int)
BEGIN
    UPDATE return_requests SET
       return_mark = true
    WHERE id = var_id;
    UPDATE cars SET available = true
    WHERE id = (SELECT car_id FROM orders WHERE id = var_id);
END;

