create
    definer = root@localhost procedure read_client_orders(IN var_client_id int)
BEGIN
    SELECT * FROM orders WHERE client_id = var_client_id AND closed = false;
END;

