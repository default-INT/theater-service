create
    definer = root@localhost procedure read_all_fuel_types()
BEGIN
	SELECT * FROM fuel_types;
END;

