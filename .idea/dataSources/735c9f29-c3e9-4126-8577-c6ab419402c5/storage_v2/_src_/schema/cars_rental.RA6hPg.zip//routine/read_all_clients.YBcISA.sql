create
    definer = root@localhost procedure read_all_clients()
BEGIN
    SELECT * FROM accounts WHERE role = false;
END;

