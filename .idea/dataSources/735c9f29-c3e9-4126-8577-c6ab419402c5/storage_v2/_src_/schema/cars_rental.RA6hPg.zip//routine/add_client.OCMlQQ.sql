create
    definer = root@localhost procedure add_client(IN var_login varchar(16), IN var_password varchar(50),
                                                  IN var_email varchar(60), IN var_full_name varchar(30),
                                                  IN var_birthday_year int)
BEGIN
    INSERT INTO accounts (login, password, email, role, full_name, birthday_year)
    VALUES (var_login, var_password, var_email, false, var_full_name, var_birthday_year);
END;

