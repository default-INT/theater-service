create
    definer = root@localhost procedure read_account(IN var_id int)
BEGIN
    SELECT * FROM accounts WHERE id = var_id;
END;

