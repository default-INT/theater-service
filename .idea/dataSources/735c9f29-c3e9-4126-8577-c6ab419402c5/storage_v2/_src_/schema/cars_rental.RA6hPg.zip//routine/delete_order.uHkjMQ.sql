create
    definer = root@localhost procedure delete_order(IN var_order_id int)
BEGIN
    DELETE FROM orders WHERE id = var_order_id;
END;

