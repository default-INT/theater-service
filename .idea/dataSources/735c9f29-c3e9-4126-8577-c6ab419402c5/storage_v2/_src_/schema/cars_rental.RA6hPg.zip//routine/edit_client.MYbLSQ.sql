create
    definer = root@localhost procedure edit_client(IN var_id int, IN var_login varchar(16), IN var_password varchar(50),
                                                   IN var_email varchar(50), IN var_full_name varchar(30),
                                                   IN var_birthday_year int)
BEGIN
    UPDATE accounts SET
                        login = var_login,
                        password = var_password,
						email = var_email,
                        full_name = var_full_name,
                        birthday_year = var_birthday_year
    WHERE id = var_id;
END;

