create
    definer = root@localhost procedure add_car(IN var_number varchar(10), IN var_model varchar(50), IN var_mileage int,
                                               IN var_year_of_issue int, IN var_price_hour int,
                                               IN var_transmission_id int, IN var_fuel_type_id int)
BEGIN
    INSERT INTO cars (number, model, mileage, year_of_issue, price_hour, transmission_id, fuel_type_id, available)
    VALUES (var_number, var_model, var_mileage, var_year_of_issue, var_price_hour, var_transmission_id, var_fuel_type_id, true);
END;

