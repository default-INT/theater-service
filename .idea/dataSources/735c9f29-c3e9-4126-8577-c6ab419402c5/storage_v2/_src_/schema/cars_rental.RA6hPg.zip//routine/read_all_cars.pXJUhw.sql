create
    definer = root@localhost procedure read_all_cars()
BEGIN
    SELECT * FROM cars;
END;

