create
    definer = root@localhost procedure read_all_return_requests_for_client(IN var_client_id int)
BEGIN
    SELECT (return_requests.id, return_requests.return_date, order_id, description, return_mark, repair_cost)
    FROM return_requests INNER JOIN orders o on return_requests.order_id = o.id
    WHERE o.client_id = var_client_id AND return_mark = false;
END;

