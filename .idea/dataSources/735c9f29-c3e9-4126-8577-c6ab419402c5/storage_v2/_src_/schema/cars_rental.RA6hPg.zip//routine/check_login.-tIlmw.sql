create
    definer = root@localhost procedure check_login(IN var_login varchar(16))
BEGIN
    SELECT COUNT(*) FROM  accounts WHERE login = var_login;
END;

